package Polymorphism.Challange;

class Ford extends Car {
    public Ford(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "Ford -> startengine()";
    }

    @Override
    public String acccelerate() {
        return "Ford -> accelerate()";
    }

    @Override
    public String brake() {
        return "Ford -> brake()";
    }

    public class Main{
    public static void main(String[] args) {

        Car car = new Car(8, "Base Car");
        System.out.println(car.startEngine());
        System.out.println(car.acccelerate());
        System.out.println(car.brake());

        Ford ford = new Ford(6,"Outlander");
        System.out.println(ford.startEngine());
        System.out.println(ford.acccelerate());
        System.out.println(ford.brake());


    }
    }
}

