package Polymorphism.Challange;

class Car {
    private boolean engine;
    private int cylinders;
    private String name;
    private int wheels;

    public Car(int cylinders, String name) {
        this.cylinders = cylinders;
        this.name = name;
        this.wheels=4;
        this.engine=true;
    }

    public int getCylinders() {
        return cylinders;
    }

    public String getName() {
        return name;
    }

    public String startEngine(){
        return "Car -> startEngine()";
    }
    public String acccelerate(){
        return "Car -> accelerator()";
    }
    public String brake(){
        return "car -> brake()";
    }

}

class Mitshubushi extends Car {
    public Mitshubushi(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "Mitsubishi -> startengine()";
    }

    @Override
    public String acccelerate() {
        return "Mitsubushi -> accelerate()";
    }

    @Override
    public String brake() {
        return "Mitsubushi -> brake()";
    }
}
public class Main{
    public static void main(String[] args) {

        Car car = new Car(8, "Base Car");
        System.out.println(car.startEngine());
        System.out.println(car.acccelerate());
        System.out.println(car.brake());

        Mitshubushi mitshubushi = new Mitshubushi(6,"Outlander");
        System.out.println(mitshubushi.startEngine());
        System.out.println(mitshubushi.acccelerate());
        System.out.println(mitshubushi.brake());

        Ford ford = new Ford(6,"Outlander");
        System.out.println(ford.startEngine());
        System.out.println(ford.acccelerate());
        System.out.println(ford.brake());

        RollsRoyce rollsroyce = new RollsRoyce(6,"Outlander");
        System.out.println(rollsroyce.startEngine());
        System.out.println(rollsroyce.acccelerate());
        System.out.println(rollsroyce.brake());

    }

    static class RollsRoyce extends Car {
        public RollsRoyce(int cylinders, String name) {
            super(cylinders, name);
        }

        @Override
        public String startEngine() {
            return "RollsRoyce -> startengine()";
        }

        @Override
        public String acccelerate() {
            return "RollsRoyce -> accelerate()";
        }

        @Override
        public String brake() {
            return "RollsRoyce -> brake()";
        }
    }
}
