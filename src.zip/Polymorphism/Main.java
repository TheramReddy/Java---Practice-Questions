package Polymorphism;
//Polymorphism: each object has multiple forms;
//Example: <To act in multiple forms.
//Static poly: resolved during compile time. eg: method overloading.
//Dynamic poly: a call to an overridden method is resolved at run time;
//
public class Main {
    public static void main(String[] args) {
        Math obj = new Math();
        int a = obj.sum(10,20);

        System.out.println(a);
    }
////    public static void main(String[] args) {
////
////        Bank obj = new HDFC();
////        obj.intrestrate();
//
//    }
}
class Math{
    public int sum(int a , int b){
        return a+b;
    }
    public int sum(int a, int b , int c){
        return a+b+c;
    }
}
//class Bank{
//    public void intrestrate(){
//        System.out.println("Depends on Bank");
//    }
//}
//class HDFC extends Bank{
//    public void intrestrate(){
//        System.out.println("10%");
//    }
//}

