package Collections;

public class Main {
    public static void main(String[] args) {

        Theatre theatre = new Theatre("INOX",8,12);
        theatre.getSeats();
        if(theatre.reserveSeat("H11")){
            System.out.println("Please complete your payment");
        }else{
            System.out.println("Sorry , seat was taken");
        }

    }
}
