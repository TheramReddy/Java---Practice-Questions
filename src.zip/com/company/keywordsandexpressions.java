package com.company;

public class keywordsandexpressions {
    public static void main(String[] args) {
        //a mile is equal to 1.609334 kilometres
        double kilometres = (100 * 1.60934);
        int highscore = 50;
        if(highscore == 50) {
            System.out.println("This is an expression");
        }
        int myvariable = 60;
        myvariable ++;
        myvariable --;

        System.out.println("This is a test ");

        System.out.println("this is" +
                "another" +
                "still more " );


    }
}
