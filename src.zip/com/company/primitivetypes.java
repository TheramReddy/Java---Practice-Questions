package com.company;

public class primitivetypes {
    public static void main(String[] args) {
        float a = Float.MIN_VALUE;
        float b = Float.MAX_VALUE;
        System.out.println("Flaot min value =" +a);
        System.out.println("Flaot max value =" +b);
        
        double c = Double.MIN_VALUE;
        double d = Double.MAX_VALUE;
        System.out.println("double min value =" +c);
        System.out.println("double max value =" +d);

        int x =5;
        float y=5.2f / 2f;
        double z=5d /2d;
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);

        

    }

}
