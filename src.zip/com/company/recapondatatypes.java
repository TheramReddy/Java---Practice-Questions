package com.company;

public class recapondatatypes {
    public static void main(String[] args){
        //byte

        //short
        //int
        //long
        //float
        //double
        //char
        //boolean
        String myString ="This is a string";
        System.out.println("mystring is equal to " +myString);
        myString = myString + " , and this is more.";
        System.out.println("mystring is equal to" +myString);


    }
}
