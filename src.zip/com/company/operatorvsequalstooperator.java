package com.company;

public class operatorvsequalstooperator {
    public static void main(String[] args) {

        int newvalue =50;
        if(newvalue ==50) {
            System.out.println("No error");

        }
        boolean iscar=false;
        if(iscar != true){
            System.out.println("This is not supposed to happen");
        }
    }
}
