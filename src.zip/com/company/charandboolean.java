package com.company;

public class charandboolean {
    public static void main(String[] args){
        char mychar = 'D';
        char myUniCodeChar = '\u011A';
        System.out.println(myUniCodeChar);
        System.out.println(mychar);
        boolean a = true;
        boolean b = false;

        boolean isCustomerOverTwentyOne = true;
        boolean isCustomerUnderEighteen = false;
        System.out.println(a);
        System.out.println(b);
        System.out.println(isCustomerOverTwentyOne);
        System.out.println(isCustomerUnderEighteen);



    }
}
