package com.company.overload;

public class Main {
    public static void main(String[] args) {
       double centimetres = calFeetAndInchesToCentimetres(6,0);
       if(centimetres < 0.0){
           System.out.println("Invalid");
       }
       calFeetAndInchesToCentimetres(100);

    }

    public static double calFeetAndInchesToCentimetres(double feet, double inches) {
        if ((feet <= 0) || ((inches < 0) || (inches > 12))) {
            System.out.println("Invalid");
            return -1;
        }
        double centimetres = (feet*12) *2.54;
        centimetres +=inches*2.54;
        System.out.println(feet + " feet " + inches + "inches = " +centimetres +" centimetres");
        return centimetres;
    }
    public static double calFeetAndInchesToCentimetres(double inches) {
        if(inches<0){
            return -1;
        }
        double feet = (int) inches/12;
        double remaininginches = (int) inches % 12;
        System.out.println(inches + " inches is equal to " + feet + " feet and " + remaininginches + " reaminning inches");
        return calFeetAndInchesToCentimetres(feet , remaininginches);
    }


}