package com.company;

public class datatypes {
    public static void main(String[] args) {

        byte bytevalue =10;
        short shortvalue=20;
        int intvalue=50;

        long longtotal = 5000L +10L * (bytevalue+shortvalue+intvalue);
        System.out.println(longtotal);

    }
}
