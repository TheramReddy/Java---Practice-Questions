package com.company;

public class kilograms {
    public static void main(String[] args){
        double pounds =200d;
        double converted = pounds * 0.45359237d;
        System.out.println("Converted kilograms =" + converted);

        double pi=3.1415927;
        double anothernumber = 3_000_000.4_567_890d;
        System.out.println(pi);
        System.out.println(anothernumber);



    }

}
