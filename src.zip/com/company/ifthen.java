package com.company;

public class ifthen {
    public static void main(String[] args) {
        int a = 100;
        if (a == 100){
            System.out.println("Your HIghest score =" + a);

        }
        int topscore = 200;
        if(topscore > a){
            System.out.println("Greater than a score " + topscore);
        }




    }
}
