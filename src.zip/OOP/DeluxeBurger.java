package OOP;

public class DeluxeBurger extends Hamburger{
    public DeluxeBurger(){
        super("Deluxe","Sausage and bacon",15.87,"White");
        super.addHamburgerAdditional1("Chips",2.75);
        super.addHamburgerAdditional2("Cola",2.9);

    }

    @Override
    public void addHamburgerAdditional1(String name, double price) {
        System.out.println("Cannot add those additional items");
    }

    @Override
    public void addHamburgerAdditional2(String name, double price) {
        System.out.println("Cannot add those additional items");
    }

    @Override
    public void addHamburgerAdditional3(String name, double price) {
        System.out.println("Cannot add those additional items");
    }

    @Override
    public void addHamburgerAdditional4(String name, double price) {
        System.out.println("Cannot add those additional items");
    }
}
