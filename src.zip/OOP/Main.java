package OOP;

import java.util.concurrent.DelayQueue;

public class Main {

    public static void main(String[] args) {

        Hamburger hamburger = new Hamburger("Basic","Sausage",3.56,"white");
        double price = hamburger.itemizeHamburger();
        hamburger.addHamburgerAdditional1("Tomato",0.27);
        hamburger.addHamburgerAdditional2("Lettuse",0.76);
        hamburger.addHamburgerAdditional3("Cheese",0.98);
        hamburger.addHamburgerAdditional4("doublecheese",1.22);

        System.out.println("Total burger price is "+ hamburger.itemizeHamburger());

        HealthyBurger healthyBurger = new HealthyBurger("Bacon","meat",5.60);
        healthyBurger.addHealthaddition1("Egg",45.6);
        healthyBurger.addHealthaddition1("cucumber",46.6);
        System.out.println("Total Healthy burger price is "+healthyBurger.itemizeHamburger());

        DeluxeBurger deluxeBurger = new DeluxeBurger();
        deluxeBurger.itemizeHamburger();
        deluxeBurger.addHamburgerAdditional1("Should not do this",56.6);



    }


}
