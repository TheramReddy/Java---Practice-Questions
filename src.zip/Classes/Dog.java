package Classes;

public class Dog {

    private String name;

    public Dog(String name) {
        this.name = name;
    }
    public void printName(){
        System.out.println("Name = " +name);
    }
}


