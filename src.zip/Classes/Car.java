package Classes;

public class Car {
    private int doors ;
    private int wheels;
    private String engine;
    private String model;
    private String colour;

    public void setModel(String model) {
        //update the parameter
        //put the private string or the main function and define.
        //use this function
        this.model = model;
    }
    public String getModel() {
        return this.model;
    }


}
