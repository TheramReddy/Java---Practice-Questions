package Classes;

public class Main {
    public static void main(String[] args) {

        //imtialize the variable with the function new.
        Car porsche = new Car();
        Car toyota = new Car();

        porsche.setModel("Supercar");
        System.out.println("Model is " + porsche.getModel());


    }
}
