package Package;

import java.awt.*;

public class MyWindow extends Frame {

}
