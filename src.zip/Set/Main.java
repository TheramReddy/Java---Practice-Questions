package Set;

import java.util.*;

public class Main {
    private static final Map<String, HeavenlyBody> solarSystem = new HashMap<>();
    private static final Set<HeavenlyBody> planets = new HashSet<>();

    public Main() {
    }

    public static void main(String[] args) {
        HeavenlyBody temp = new HeavenlyBody("Mercury", 88.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        temp = new HeavenlyBody("Venus", 225.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        temp = new HeavenlyBody("Earth", 365.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        HeavenlyBody tempMoon = new HeavenlyBody("Moon", 27.0D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        temp = new HeavenlyBody("Mars", 687.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        tempMoon = new HeavenlyBody("Deimos", 1.3D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        tempMoon = new HeavenlyBody("Phobos", 0.3D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        temp = new HeavenlyBody("Jupiter", 4332.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        tempMoon = new HeavenlyBody("Io", 1.8D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        tempMoon = new HeavenlyBody("Europa", 3.5D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        tempMoon = new HeavenlyBody("Ganymede", 7.1D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        tempMoon = new HeavenlyBody("Callisto", 16.7D);
        solarSystem.put(tempMoon.getName(), tempMoon);
        temp.addMoon(tempMoon);
        temp = new HeavenlyBody("Saturn", 10759.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        temp = new HeavenlyBody("Uranus", 30660.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        temp = new HeavenlyBody("Neptune", 165.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        temp = new HeavenlyBody("Pluto", 248.0D);
        solarSystem.put(temp.getName(), temp);
        planets.add(temp);
        System.out.println("Planets");

        for (HeavenlyBody planet : planets) {
            System.out.println("\t" + planet.getName());
        }

        HeavenlyBody body = solarSystem.get("Mars");
        System.out.println("Moons of " + body.getName());

        for (HeavenlyBody jupiterMoon : body.getSatellites()) {
            System.out.println("\t" + jupiterMoon.getName());
        }

        Set<HeavenlyBody> moons = new HashSet<>();
        Iterator<HeavenlyBody> var10 = planets.iterator();

        HeavenlyBody moon;
        while(var10.hasNext()) {
            moon = var10.next();
            moons.addAll(moon.getSatellites());
        }

        System.out.println("All Moons");
        var10 = moons.iterator();

        while(var10.hasNext()) {
            moon = var10.next();
            System.out.println("\t" + moon.getName());
        }

    }
}
