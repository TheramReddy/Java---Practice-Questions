package Parsing;

public class parsiing {
    public static void main(String[] args) {
        String numberasstring = "2018.125";
        System.out.println( "Numberstring = " + numberasstring);

        double number= Double.parseDouble(numberasstring);
        System.out.println("Number as  = " +number);

        numberasstring+=1;
        number+=1;

        System.out.println("number as string " + numberasstring);
        System.out.println("number as " + number);

    }
}
