
package ReverseArray;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] array = {234,4453,3455,345,35345,534};
        System.out.println("Array= "+Arrays.toString(array) );
        reverse(array);
        System.out.println("Reversed array= "+Arrays.toString(array));

    }

    private static void reverse(int[] array){

        int maxIndex = array.length-1;
        int halfLength = array.length/2;
        for(int i=0;i<halfLength;i++){
            int temp = array[i];
            array[i] = array[maxIndex - i];
            array[maxIndex - i] = temp;

        }
    }
}
//Explanation:
//int temp = array[i]; ---->temp=1;
//maxIndex to get the value of the array to put in the new array.
//array[i]=array[maxIndex-i];
//now change array[maxIndex-i]=temp;;