package Inheritance;

public class main {
    public static void main(String[] args) {

        Animal animal = new Animal("Animal",1,1,5,5);

        Dog dog = new  Dog("YARKIS",8,10,10,2,1,2,"FUR");
        dog.eat();
        dog.walk();
        dog.run();
    }
}
