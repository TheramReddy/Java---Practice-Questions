package Generics.Challemge;

import Generics.Example.Player;

public class FootballPlayer extends Player {
    public FootballPlayer(String name) {
        super(name);
    }
}
