package Generics.Example;

public class BasevallPlayer extends Player {
    public BasevallPlayer(String name) {
        super(name);
    }

}
