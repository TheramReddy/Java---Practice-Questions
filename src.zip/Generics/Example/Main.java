package Generics.Example;

public class Main {
    public static void main(String[] args) {

        FootballPlayer joe = new FootballPlayer("joe");
        BasevallPlayer pat = new BasevallPlayer("pat");
        SoccerPlayer beckam = new SoccerPlayer("Beckam");

        Team adelaidcrows = new Team("aDELAIDE CROWS");
        adelaidcrows.addPlayer(joe);
        adelaidcrows.addPlayer(pat);
        adelaidcrows.addPlayer(beckam);

        System.out.println(adelaidcrows.numPlyers());


    }
}
