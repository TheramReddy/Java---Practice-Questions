package Constructors;

public class Vipperson {
    public Vipperson() {
    }

    public boolean getEmailaddress() {

        return true;
    }

    public boolean getName() {
        return true;
    }

}
