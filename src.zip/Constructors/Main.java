package Constructors;

public class Main {
    public static void main(String[] args) {
        account naniaccount = new account();


        System.out.println(naniaccount.getAccountnumber());
        System.out.println(naniaccount.getAccoutnbalance());
        System.out.println(naniaccount.getCustomerphonenumber());
        System.out.println(naniaccount.getSudtomeremailadress());

        naniaccount.withdrawl(100.00);
        naniaccount.deposit(50.00);
        naniaccount.withdrawl(100.00);

        Vipperson person1=new Vipperson();
        System.out.println(person1.getName());

        Vipperson person2 = new Vipperson();
        System.out.println(person2.getName());

        Vipperson person3 = new Vipperson();
        System.out.println(person3.getName());
        System.out.println(person3.getEmailaddress());





    }
}
