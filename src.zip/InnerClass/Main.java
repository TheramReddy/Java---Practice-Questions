package InnerClass;

import Examples.Interface.Gearbox;

public class Main {
    public static void main(String[] args) {
    }
}
