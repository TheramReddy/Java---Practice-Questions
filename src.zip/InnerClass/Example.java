package InnerClass;

class Testmemberouter1{
    private int data=30;
    class inner{
        void msg(){
            System.out.println("data is "+data);
        }
    }


}

public class Example {
    public static void main(String[] args) {
        Testmemberouter1 obj = new Testmemberouter1();
        Testmemberouter1.inner in = obj.new inner();
        in.msg();
    }
}
