package Encapsulation;

public class Main {

    public static void main(String[] args) {

//        EnhancedPlayer player = new EnhancedPlayer("Nani",50,"Gun");
//        System.out.println("Intial health is "+player.getHealth());



    }
}
