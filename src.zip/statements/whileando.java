package statements;

public class whileando {
    public static void main(String[] args) {
        //from 1 to 5
        int count =1  ;
        while(count !=6) {
            System.out.println("Count value is " + count);
            count++;

        }

        /// from 1 to 1000
        //if the count on start and end of while () is nt matched then it ll be a infinite loop

        count = 1;
        do {
            System.out.println("Count value was " + count);
            count++;
            if(count>100) {
                break;
            }

        }while (count!=1);


        //iseven number

        int number = 4;
        int finishnumber = 20;
        while (number <= finishnumber) {
            number++;
            if (!isevennumber(number)) {
                continue;
            }
            System.out.println("Even number " + number);
        }



    }
    public static boolean isevennumber(int number) {
        if((number%2) == 0) {
            return true;
        }else {
            return false;
        }

    }

}
