package statements;

import java.util.Locale;

public class switchclass {
    public static void main(String[] args) {


        int switchvalue =6;
        switch(switchvalue) {
            case 1:
                System.out.println("value was 1");
                break;
            case 2:
                System.out.println("value was 2");
                break;
            case 3 : case 4 : case 5:
                System.out.println("was a 3 or 4 or 5");
                System.out.println("Actually it was a " +switchvalue);
                break;
            default:
                System.out.println("was not in between 1 to 5");
                break;


        }

        char charvalue = 'A';
        switch(charvalue) {
            case 'A':
                System.out.println("A was found");
                break;
            case 'B':
                System.out.println("B was found");
                break;
            case 'C' : case 'D' : case 'E' :
                System.out.println(charvalue + " was found");
                break;
            default:
                System.out.println("Couldn't find");
                break;
        }

        String month ="JunE";
        switch(month.toLowerCase()) {
            case "january":
                System.out.println("Jan");
                break;
            case "june":
                System.out.println("Jun");
                break;
            default:
                System.out.println("Not sure");
                break;
        }

    }
}
