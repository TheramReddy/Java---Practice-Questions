package statements;

public class Digitsumchallenge {
    public static void main(String[] args) {
        System.out.println("Sum of digits in number 125 is " + sumDigits(125));
        System.out.println("Sum of digits in number -125 is " + sumDigits(-125));
        System.out.println("Sum of digits in number 5 is " + sumDigits(5));
        System.out.println("Sum of digits in number 13244 is " + sumDigits(13244));
        System.out.println("Sum of digits in number 0 is " + sumDigits(0));



    }
    private static int sumDigits( int number) {
        if (number < 10) {
            return -1;
        }
        int sum = 0 ;
        // 125 --> 125/ 10 = 12 --> 12*10 = 120 --> 125-120 = 5
        while (number>0) {
            //extract the least significant digit
            int digit = number % 10;
            sum += digit ;
            /// drop thge leat significant digit
            number /= 10 ;  //same as number = number/10

        }
        return sum;

    }
}
