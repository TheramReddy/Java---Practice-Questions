package statements;

public class challengewhileloop {
    public static void main(String[] args) {
        int number = 4;
        int finishnumber = 20;
        int evennumbersfound = 0 ;
        while (number <= finishnumber) {
            number++;
            if (!isevennumber(number)) {
                continue;
            }
            System.out.println("Even number " + number);
            evennumbersfound++;
            if (evennumbersfound>=5) {
                break;
            }
        }
        System.out.println("Total even numbers found = " + evennumbersfound);


    }
    public static boolean isevennumber(int number) {
        if((number%2) == 0) {
            return true;
        }else {
            return false;
        }

    }

}
