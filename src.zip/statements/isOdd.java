package statements;

public class isOdd {
    public static void main(String[] args) {
        System.out.println(isOdd(2,100));


    }
    public static boolean isOdd(int i , int j){
        if((i<=0) || (j<=0)){
            return false;

        }else {
            for (i=1 ; i<j ; i+=2) {
                System.out.println("The numbers are " + i);
            }

        }return true;

    }


}
