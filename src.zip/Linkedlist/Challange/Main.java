package Linkedlist.Challange;

import org.xml.sax.helpers.AttributeListImpl;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;

public class Main {

    private static ArrayList<Album> albums = new ArrayList<Album>();

    public static void main(String[] args) {
        Album album = new Album("StormBringer" , "Deep purple");
        album.addSong("StormBringer" , 23.32);
        album.addSong("Kiss" , 2.32);
        album.addSong("God's Country " , 2.34);
        albums.add(album);

        album = new Album("For those  who to Rock" , "AC/DC");
        album.addSong("Good on you",23.32);
        album.addSong("For you" , 3.44);
        albums.add(album);

        LinkedList<Song> playList = new LinkedList<Song>();
        albums.get(0).addToPlaylist("Storm Bringer", playList);//does nto exist
        albums.get(0).addToPlaylist(1,playList);
        albums.get(0).addToPlaylist(21,playList);
        //doesn't exist
        play(playList);


    }
    private static void play(LinkedList<Song> playList){
        ListIterator<Song> listIterator = playList.listIterator();
        if(playList.size()==0){
            System.out.println("No songs in plaList");
            return;

        }else{
            System.out.println("Now playign "+listIterator.next().toString());
        }
    }

}