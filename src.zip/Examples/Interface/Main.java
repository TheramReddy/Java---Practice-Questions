package Examples.Interface;

public class Main {

    public static void main(String[] args) {

        ITelephone nanisphone;
        nanisphone = new DeskPhone(746236492);
        nanisphone.powerOn();
        nanisphone.callPhone(342545664);
        nanisphone.answer();

        nanisphone = new MobilePhone(2352343);
        nanisphone.callPhone(234342);
        nanisphone.answer();
    }

}
