package arithmetic;

public class arithmetic {
    public static void main(String[] args) {
        System.out.println(addition(10,11));
        System.out.println(subtraction(10,11));
        System.out.println(multiplication(10,11));
        System.out.println(division(10,11));

    }
    public static double addition(double a , double b) {

        return a+b ;

    }
    public static double subtraction(double a , double b) {

        return a-b ;

    }
    public static double multiplication(double a , double b) {

        return a*b ;

    }
    public static double division(double a , double b) {

        return a/b ;

    }

}
