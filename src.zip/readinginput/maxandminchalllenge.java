package readinginput;

import java.util.Scanner;

public class maxandminchalllenge {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int min=Integer.MIN_VALUE;
        int max=Integer.MAX_VALUE;

 //       int count = 0;


        while (true) {
            System.out.println("Enter the number: ");
            boolean isanint = scanner.hasNextInt();
//            count++;

            if (isanint) {
                int number =scanner.nextInt();

                if (number > max) {
                    max=number;
                }
                if (number < min) {
                    min=number;
                }
            }else {
                System.out.println("Invalid number");
                break;
            }
            scanner.nextLine();
        }


        System.out.println("Min = " +min + " Max = " + max);

        scanner.close();
    }
}
