package readinginput;

import java.util.Scanner;

public class userinput {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);

        System.out.println("Enter your year of birth ");

        boolean hasnextint = scanner.hasNextInt();
        //to check if the next input is int

        if(hasnextint) {

            int yearofbirth = scanner.nextInt();
            scanner.nextLine();
            //to close the scanner part
            //by scanner function we able to retrieve information from the user.
            int age = 2020-yearofbirth;
            System.out.println("Enter your name : " );
            String name = scanner.nextLine();
            //handle next line character.

            if(age>=0 && age<=100) {
                System.out.println("Your name is " +name + " , and you are" + age + " years old");
            } else {
                System.out.println("Invalid Year of birth ");
            }
        }else {
            System.out.println("Unable to parse year of birth");
        }

        scanner.close(); //to close all the part

    }
}
