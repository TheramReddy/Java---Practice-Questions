package AbstractClass.Challenge;

public class Main {
}
