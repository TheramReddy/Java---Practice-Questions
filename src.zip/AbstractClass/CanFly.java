package AbstractClass;

public interface CanFly {
    void fly();
}
